// swiftlint:disable:this file_name
// swiftlint:disable all
// swift-format-ignore-file
// swiftformat:disable all
// Generated using tuist — https://github.com/tuist/tuist



#if os(macOS)
#if hasFeature(InternalImportsByDefault)
public import AppKit
#else
import AppKit
#endif
#else
#if hasFeature(InternalImportsByDefault)
public import UIKit
#else
import UIKit
#endif
#endif

#if canImport(SwiftUI)
#if hasFeature(InternalImportsByDefault)
public import SwiftUI
#else
import SwiftUI
#endif
#endif

// MARK: - Asset Catalogs

public enum ChristLinkFaithEventsNeaAsset: Sendable {
  public enum Assets {
  public static let accentColor = ChristLinkFaithEventsNeaColors(name: "AccentColor")
    public static let activityIndicatorColor = ChristLinkFaithEventsNeaColors(name: "activityIndicatorColor")
    public static let inactiveTabBarItemColor = ChristLinkFaithEventsNeaColors(name: "inactiveTabBarItemColor")
    public static let navigationBarTintColor = ChristLinkFaithEventsNeaColors(name: "navigationBarTintColor")
    public static let sidebarBackgroundColor = ChristLinkFaithEventsNeaColors(name: "sidebarBackgroundColor")
    public static let sidebarTextColor = ChristLinkFaithEventsNeaColors(name: "sidebarTextColor")
    public static let statusBarBackgroundColor = ChristLinkFaithEventsNeaColors(name: "statusBarBackgroundColor")
    public static let tabBarTintColor = ChristLinkFaithEventsNeaColors(name: "tabBarTintColor")
    public static let tintColor = ChristLinkFaithEventsNeaColors(name: "tintColor")
    public static let titleColor = ChristLinkFaithEventsNeaColors(name: "titleColor")
  }
  public enum Images {
  public static let headerImage = ChristLinkFaithEventsNeaImages(name: "HeaderImage")
    public static let launchBackground = ChristLinkFaithEventsNeaImages(name: "LaunchBackground")
    public static let launchCenter = ChristLinkFaithEventsNeaImages(name: "LaunchCenter")
    public static let navBarImage = ChristLinkFaithEventsNeaImages(name: "NavBarImage")
    public static let chevronDown = ChristLinkFaithEventsNeaImages(name: "chevronDown")
    public static let chevronUp = ChristLinkFaithEventsNeaImages(name: "chevronUp")
    public static let gear = ChristLinkFaithEventsNeaImages(name: "gear")
    public static let leftImage = ChristLinkFaithEventsNeaImages(name: "leftImage")
    public static let navImage = ChristLinkFaithEventsNeaImages(name: "navImage")
    public static let rightImage = ChristLinkFaithEventsNeaImages(name: "rightImage")
  }
}

// MARK: - Implementation Details

public final class ChristLinkFaithEventsNeaColors: Sendable {
  public let name: String

  #if os(macOS)
  public typealias Color = NSColor
  #elseif os(iOS) || os(tvOS) || os(watchOS) || os(visionOS)
  public typealias Color = UIColor
  #endif

  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, visionOS 1.0, *)
  public var color: Color {
    guard let color = Color(asset: self) else {
      fatalError("Unable to load color asset named \(name).")
    }
    return color
  }

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
  public var swiftUIColor: SwiftUI.Color {
      return SwiftUI.Color(asset: self)
  }
  #endif

  fileprivate init(name: String) {
    self.name = name
  }
}

public extension ChristLinkFaithEventsNeaColors.Color {
  @available(iOS 11.0, tvOS 11.0, watchOS 4.0, macOS 10.13, visionOS 1.0, *)
  convenience init?(asset: ChristLinkFaithEventsNeaColors) {
    let bundle = Bundle.module
    #if os(iOS) || os(tvOS) || os(visionOS)
    self.init(named: asset.name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    self.init(named: NSColor.Name(asset.name), bundle: bundle)
    #elseif os(watchOS)
    self.init(named: asset.name)
    #endif
  }
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
public extension SwiftUI.Color {
  init(asset: ChristLinkFaithEventsNeaColors) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle)
  }
}
#endif

public struct ChristLinkFaithEventsNeaImages: Sendable {
  public let name: String

  #if os(macOS)
  public typealias Image = NSImage
  #elseif os(iOS) || os(tvOS) || os(watchOS) || os(visionOS)
  public typealias Image = UIImage
  #endif

  public var image: Image {
    let bundle = Bundle.module
    #if os(iOS) || os(tvOS) || os(visionOS)
    let image = Image(named: name, in: bundle, compatibleWith: nil)
    #elseif os(macOS)
    let image = bundle.image(forResource: NSImage.Name(name))
    #elseif os(watchOS)
    let image = Image(named: name)
    #endif
    guard let result = image else {
      fatalError("Unable to load image asset named \(name).")
    }
    return result
  }

  #if canImport(SwiftUI)
  @available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
  public var swiftUIImage: SwiftUI.Image {
    SwiftUI.Image(asset: self)
  }
  #endif
}

#if canImport(SwiftUI)
@available(iOS 13.0, tvOS 13.0, watchOS 6.0, macOS 10.15, visionOS 1.0, *)
public extension SwiftUI.Image {
  init(asset: ChristLinkFaithEventsNeaImages) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle)
  }

  init(asset: ChristLinkFaithEventsNeaImages, label: Text) {
    let bundle = Bundle.module
    self.init(asset.name, bundle: bundle, label: label)
  }

  init(decorative asset: ChristLinkFaithEventsNeaImages) {
    let bundle = Bundle.module
    self.init(decorative: asset.name, bundle: bundle)
  }
}
#endif

// swiftformat:enable all
// swiftlint:enable all
